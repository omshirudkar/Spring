package com.cdac.entity_annotation;

public interface Trainer {

	public void Train();
}
