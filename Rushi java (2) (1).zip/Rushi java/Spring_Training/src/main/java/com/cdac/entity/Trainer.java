package com.cdac.entity;

public interface Trainer {

	public void Train();
}
