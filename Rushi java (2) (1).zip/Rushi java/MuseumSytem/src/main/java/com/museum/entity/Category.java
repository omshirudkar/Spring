package com.museum.entity;

public enum Category {

	PAINTING,SCULPTURE,ARTIFACT
}
